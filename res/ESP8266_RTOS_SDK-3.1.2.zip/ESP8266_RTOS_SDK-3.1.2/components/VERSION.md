# Version of 3rd party components

## axTLS

## cJSON
- Source: https://github.com/DaveGamble/cJSON
- Version: 1.7.6

## freeRTOS
- Source: https://github.com/aws/amazon-freertos
- Version: 1.2.3(10.0.1)

## Lwip
- Source: https://git.savannah.nongnu.org/git/lwip.git
- Version: 2.0.3

## mbedTLS
- Source: https://github.com/ARMmbed/mbedtls
- Version: 2.8.0

## nopoll(websocket)

## paho MQTT
- Source: https://github.com/eclipse/paho.mqtt.embedded-c
- Version: 29ab2aa

## spiffs

## wolfSSL
- Source: https://github.com/wolfSSL/wolfssl
- Version: 3.14.0

> Espressif uses commercial version.