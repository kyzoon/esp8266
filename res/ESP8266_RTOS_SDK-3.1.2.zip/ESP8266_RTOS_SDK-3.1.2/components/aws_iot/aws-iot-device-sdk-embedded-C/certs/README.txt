# Copy certificates for running the samples and tests provided with the SDK into this directory
# Certificates can be created and downloaded from the AWS IoT Console
# The IoT Client takes the full path of the certificates as an input parameter while initializing
# This is the default folder for the certificates only for samples and tests. A different path can be specified if required.